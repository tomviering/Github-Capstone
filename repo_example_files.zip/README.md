# Capstone project

This is such a great project. 

# Group members

The group members of this project are:


# How to install 

You will need Python version 3.10 to run this project. The code can be found in the `code` directory. The data is found in `data`. 




